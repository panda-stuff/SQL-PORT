<?php

    // Editable main application entry point.

    $database_status = 'Not connected';

    try
    {

        $pdo = new PDO('mysql:host=127.0.0.1;port=3306;dbname=main;charset=utf8mb4', 'root', 'root', [
            PDO::ATTR_ERRMODE => PDO::ERRMODE_EXCEPTION
        ]);

        $database_status = 'Connected to MariaDB';

    }
    catch (PDOException $error)
    {

        $database_status = 'MariaDB connection unavailable';

    }

?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>SQL PORT</title>
</head>
<body>
    <h1>SQL PORT</h1>
    <p><?= htmlspecialchars($database_status, ENT_QUOTES, 'UTF-8') ?></p>
    <p>Edit <code>app/index.php</code> to build your project.</p>
    <p><a href="http://127.0.0.1:4096/phpmyadmin/">Open phpMyAdmin</a></p>
</body>
</html>
