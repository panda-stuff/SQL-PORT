const $ = id => document.getElementById(id);
let state = null;
const module_states = new Map();
const module_status_timers = new Map();

async function request(path, method = 'GET')
{
    const response = await fetch(path, { method, headers: { 'Content-Type': 'application/json' } });
    const body = await response.json();
    if (!response.ok) throw Error(body.error || 'Request failed');
    return body;
}

function showActionStatus(element, value, busy = false, error = false)
{
    element.replaceChildren();
    if (!value) return;

    const dot = document.createElement('span');
    dot.className = `action-indicator${busy ? ' busy' : ''}${error ? ' error' : ''}`;
    dot.setAttribute('aria-hidden', 'true');

    const text = document.createElement('span');
    text.textContent = value;
    element.append(dot, text);
}

function message(value, busy = false, error = false)
{
    showActionStatus($('message'), value, busy, error);
}

async function act(name, action)
{
    try
    {
        message(`${action}: ${name}…`);
        await request(`/api/service/${encodeURIComponent(name)}/${action}`, 'POST');
        await refresh();
        message(`${name}: ${action} requested.`);
    }
    catch (error)
    {
        message(error.message);
    }
}

async function refresh()
{
    try
    {
        state = await request('/api/status');
        $('server_status').textContent = 'Manager Online';
        $('server_status').classList.remove('off');
        $('startup_url').textContent = state.startup_url;
        $('services').replaceChildren();

        for (const service of state.services)
        {
            const panel = document.createElement('section');
            panel.className = 'panel';
            const head = document.createElement('div');
            head.className = 'service-head';
            const info = document.createElement('div');
            const title = document.createElement('strong');
            title.textContent = service.name;
            const subtitle = document.createElement('p');
            subtitle.className = 'muted small';
            subtitle.textContent = service.enabled ? 'Configured service' : 'Disabled in services.json';
            info.append(title, subtitle);
            const pill = document.createElement('span');
            pill.className = `pill ${service.running ? '' : 'off'}`;
            pill.textContent = service.running ? 'Running' : 'Stopped';
            head.append(info, pill);
            const buttons = document.createElement('div');
            buttons.className = 'buttons';
            for (const [action, label, disabled] of [
                ['start', 'Start', service.running],
                ['stop', 'Stop', !service.running],
                ['restart', 'Restart', !service.running]
            ])
            {
                const button = document.createElement('button');
                button.className = 'btn';
                button.textContent = label;
                button.disabled = disabled;
                button.onclick = () => act(service.name, action);
                buttons.append(button);
            }
            const updates = document.createElement('div');
            updates.className = 'buttons update-buttons';
            const config = document.createElement('button');
            config.className = 'btn outline';
            config.textContent = 'Config';
            config.onclick = () => openConfig(service.name);
            buttons.append(config);
            const install = document.createElement('button');
            install.className = 'btn primary';
            install.textContent = 'Install / Update';
            install.onclick = () => moduleAction(service.name, 'install');
            updates.append(install);
            panel.dataset.module = service.name;
            if (service.error)
            {
                const failure = document.createElement('p');
                failure.className = 'muted small';
                failure.style.cssText = 'color:#ef7f87;white-space:pre-wrap;margin:10px 0;overflow-wrap:anywhere';
                failure.textContent = service.error;
                panel.append(failure);
            }
            panel.append(head, buttons, updates);
            addModuleStatus(panel, service.name);
            showAvailableUpdate(panel, service.name);
            $('services').append(panel);
        }
        const pma = document.createElement('section');
        pma.className = 'panel';
        const pmaTitle = document.createElement('div');
        pmaTitle.className = 'service-head';
        const label = document.createElement('strong');
        label.textContent = 'phpMyAdmin';
        const note = document.createElement('span');
        note.className = 'muted small';
        const phpInstalled = !!(state?.updates?.PHP?.installed && state.updates.PHP.installed !== 'Not installed');
        note.textContent = phpInstalled ? 'PHP present' : 'PHP missing';
        pmaTitle.append(label, note);
        const pmaButtons = document.createElement('div');
        pmaButtons.className = 'buttons module-update-buttons';
        const configPma = document.createElement('button');
        configPma.className = 'btn outline';
        configPma.textContent = 'Config';
        configPma.onclick = () => openConfig('phpMyAdmin');
        pmaButtons.append(configPma);
        const pmaUpdates = document.createElement('div');
        pmaUpdates.className = 'buttons update-buttons';
        const installPma = document.createElement('button');
        installPma.className = 'btn primary';
        installPma.textContent = 'Install / Update';
        installPma.onclick = () => moduleAction('phpMyAdmin', 'install');
        pmaUpdates.append(installPma);
        pma.append(pmaTitle, pmaButtons, pmaUpdates);
        pma.dataset.module = 'phpMyAdmin';
        addModuleStatus(pma, 'phpMyAdmin');
        showAvailableUpdate(pma, 'phpMyAdmin');
        $('services').append(pma);
    }
    catch (error)
    {
        $('server_status').textContent = 'Disconnected';
        $('server_status').classList.add('off');
        message(error.message);
    }
}

function showAvailableUpdate(panel, name)
{
    const info = state?.updates?.[name];
    if (module_states.get(name)?.busy) return;

    const alert = document.createElement('p');
    alert.className = 'muted small available-update';

    if (!info)
    {
        showActionStatus(alert, 'Checking latest version…', true);
    }
    else if (info.error)
    {
        showActionStatus(alert, `Version check failed: ${info.error}`, false, true);
    }
    else if (info.update_available)
    {
        const installed = info.installed ? 'Installed' : 'Not installed';
        alert.textContent = `New version available: ${info.available} (${installed})`;
    }
    else if (info.installed)
    {
        alert.textContent = `Latest version: ${info.available} (Installed)`;
    }
    else
    {
        return;
    }

    panel.append(alert);
}

async function openConfig(name)
{
    try
    {
        await request(`/api/config/${encodeURIComponent(name)}`, 'POST');
    }
    catch (error)
    {
        setModuleState(name, `Error: ${error.message}`, false, true);
    }
}

function addModuleStatus(panel, name)
{
    const status = document.createElement('p');
    status.className = 'muted small module-status';
    status.setAttribute('role', 'status');
    status.setAttribute('aria-live', 'polite');
        panel.append(status);
    updateModuleUI(panel, name);
}

function updateModuleUI(panel, name)
{
    const details = module_states.get(name);
    const busy = !!details?.busy;

    panel.querySelectorAll('.update-buttons button, .module-update-buttons button').forEach(button => {
        button.disabled = busy;
    });

    const status = panel.querySelector('.module-status');
    if (status)
    {
        showActionStatus(status, details?.text || '', busy, !!details?.error);
        status.style.color = details?.error ? '#ef7f87' : '';
    }
}

function setModuleState(name, text, busy = false, error = false)
{
    module_states.set(name, { text, busy, error });
    for (const panel of document.querySelectorAll('[data-module]'))
    {
        if (panel.dataset.module === name) updateModuleUI(panel, name);
    }
}

async function moduleAction(name, action)
{
    if (module_states.get(name)?.busy) return;

    clearTimeout(module_status_timers.get(name));
    module_status_timers.delete(name);

    const hideCompletedStatus = () => {
        const timer = setTimeout(() => {
            if (!module_states.get(name)?.busy) setModuleState(name, '');
            module_status_timers.delete(name);
        }, 10000);
        module_status_timers.set(name, timer);
    };

    const label = action === 'check' ? 'Checking official releases…' : 'Installing / updating official package…';
    setModuleState(name, label, true);

    try
    {
        await request(`/api/update/${encodeURIComponent(name)}/${action}`, 'POST');

        while (true)
        {
            const result = await request(`/api/update/${encodeURIComponent(name)}/status`);
            if (result.state !== 'checking' && result.state !== 'installing')
            {
                if (result.state === 'error')
                {
                    setModuleState(name, `Error: ${result.error || 'Update failed'}`, false, true);
                }
                else if (result.state === 'done')
                {
                    const info = result.result || {};
                    setModuleState(name, info.message || JSON.stringify(info), false);
                }
                else
                {
                    setModuleState(name, 'Update operation ended without a result.', false, true);
                }
                await refresh();
                hideCompletedStatus();
                return;
            }

            await new Promise(resolve => setTimeout(resolve, 1000));
        }
    }
    catch (error)
    {
        setModuleState(name, `Error: ${error.message}`, false, true);
        hideCompletedStatus();
    }
}

$('copy_url').onclick = () => navigator.clipboard.writeText(state.startup_url).then(() => message('Address copied.')).catch(e => message(e.message));
$('open_main').onclick = () => { if (state) windowAction('open-browser'); };
$('restart_all').onclick = async () => {
    try { await request('/api/restart-all', 'POST'); await refresh(); message('Services restarted.'); }
    catch (error) { message(error.message); }
};
refresh();
setInterval(refresh, 5000);

// Window controls are defined in editable HTML/CSS; Rust executes only native actions.
async function windowAction(action)
{
    try
    {
        const response = await fetch('/api/window/' + action, { method: 'POST' });
        if (!response.ok) throw Error('Window action failed');
    }
    catch (error)
    {
        message(error.message);
    }
}

// Dark by default; a manually selected theme persists across launches.
const theme_key = 'sql_port_theme';
function setTheme(theme)
{
    document.documentElement.setAttribute('data-theme', theme);
    localStorage.setItem(theme_key, theme);
    $('theme_toggle').title = theme === 'dark' ? 'Switch to light mode' : 'Switch to dark mode';
    $('theme_toggle').setAttribute('aria-label', $('theme_toggle').title);
}
setTheme(localStorage.getItem(theme_key) === 'light' ? 'light' : 'dark');
$('theme_toggle').onclick = () => setTheme(document.documentElement.getAttribute('data-theme') === 'dark' ? 'light' : 'dark');

$('window_minimize').onclick = () => windowAction('minimize');
$('window_maximize').onclick = () => windowAction('maximize');
$('window_close').onclick = () => windowAction('close');
$('window_drag').onmousedown = event => {
    if (event.button === 0) windowAction('drag');
};
