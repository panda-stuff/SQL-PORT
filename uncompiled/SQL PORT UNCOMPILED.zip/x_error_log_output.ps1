$ErrorActionPreference = 'Stop'

$repo = $PSScriptRoot
$desktop = [Environment]::GetFolderPath('Desktop')
$output = Join-Path $desktop 'SQL_PORT_Error_Logs'
New-Item -ItemType Directory -Path $output -Force | Out-Null

$ghCommand = Get-Command gh -ErrorAction SilentlyContinue
if ($ghCommand) {
    $gh = $ghCommand.Source
} elseif (Test-Path 'C:\Program Files\GitHub CLI\gh.exe') {
    $gh = 'C:\Program Files\GitHub CLI\gh.exe'
} else {
    Write-Host 'GitHub CLI (gh.exe) not found. Install GitHub CLI first.' -ForegroundColor Red
    exit 1
}

Set-Location -LiteralPath $repo

& git rev-parse --is-inside-work-tree *> $null
if ($LASTEXITCODE -ne 0) {
    Write-Host 'This script must be placed in the root folder of your Git repository.' -ForegroundColor Red
    exit 1
}

Write-Host 'Finding latest GitHub Actions run...'
$runJson = & $gh run list --limit 1 --json databaseId,displayTitle,status,conclusion,createdAt,headSha,workflowName 2>&1
if ($LASTEXITCODE -ne 0) {
    Write-Host ($runJson | Out-String) -ForegroundColor Red
    exit 1
}

$runs = @($runJson | ConvertFrom-Json)
if ($runs.Count -eq 0) {
    Write-Host 'No GitHub Actions runs found.' -ForegroundColor Yellow
    exit 1
}

$run = $runs[0]
$runId = [string]$run.databaseId
$runFolder = Join-Path $output "run_$runId"
New-Item -ItemType Directory -Path $runFolder -Force | Out-Null

$run | ConvertTo-Json -Depth 8 | Set-Content -LiteralPath (Join-Path $runFolder 'run_info.json') -Encoding UTF8

Write-Host "Collecting logs for run $runId ($($run.conclusion))..."

& $gh run view $runId --json jobs,conclusion,status,headSha,url > (Join-Path $runFolder 'jobs.json') 2>&1
& $gh run view $runId > (Join-Path $runFolder 'run_summary.txt') 2>&1
& $gh run view $runId --log > (Join-Path $runFolder 'full_log.txt') 2>&1
& $gh run view $runId --log-failed > (Join-Path $runFolder 'failed_steps.txt') 2>&1

$allLogs = Join-Path $runFolder 'full_log.txt'
$errors = Join-Path $runFolder 'errors_and_context.txt'

if (Test-Path $allLogs) {
    $lines = @(Get-Content -LiteralPath $allLogs)
    $lineNumbers = [System.Collections.Generic.HashSet[int]]::new()
    $pattern = '(?i)(^|\s)(error(\[|:|\s)|fatal:|failed to|Caused by:|##\[error\]|panic|exit code|could not compile|linking with|error\[E\d+\])'

    for ($i = 0; $i -lt $lines.Count; $i++) {
        if ($lines[$i] -match $pattern) {
            $start = [Math]::Max(0, $i - 5)
            $end = [Math]::Min($lines.Count - 1, $i + 10)
            for ($j = $start; $j -le $end; $j++) { [void]$lineNumbers.Add($j) }
        }
    }

    $selected = @($lineNumbers | Sort-Object | ForEach-Object { $lines[$_] })
    if ($selected.Count -eq 0) { $selected = @('No matching compiler/error lines found. See full_log.txt and failed_steps.txt.') }
    $selected | Set-Content -LiteralPath $errors -Encoding UTF8
}

$zipPath = Join-Path $output "SQL_PORT_Logs_$runId.zip"
if (Test-Path $zipPath) { Remove-Item -LiteralPath $zipPath -Force }
Compress-Archive -Path (Join-Path $runFolder '*') -DestinationPath $zipPath -Force

Write-Host ''
Write-Host "Logs saved to: $runFolder" -ForegroundColor Green
Write-Host "Upload this ZIP to your favorite AI chat for debugging, and have fun fixing it: $zipPath" -ForegroundColor Green
Write-Host ''
