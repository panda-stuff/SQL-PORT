#![cfg_attr(target_os = "windows", windows_subsystem = "windows")]

use serde::{Deserialize, Serialize};
use serde_json::json;
use std::{collections::HashMap, fs::{self, File, OpenOptions}, io::Read, path::{Path, PathBuf}, process::{Child, Command, Stdio}, sync::{Arc, Mutex}, thread, time::{Duration, Instant}};
use tiny_http::{Header, Method, Response, Server, StatusCode};
use tao::{event::{Event, WindowEvent}, event_loop::{ControlFlow, EventLoopBuilder}, window::WindowBuilder};
use wry::WebViewBuilder;
use tray_icon::{TrayIconBuilder, TrayIconEvent, Icon as TrayIcon, menu::{Menu, MenuItem, MenuEvent}};
use tao::window::Icon as WindowIcon;
use tao::event_loop::EventLoopProxy;
mod updater;
mod database;


#[derive(Clone, Deserialize)]
struct Application { name: String, host: String, port: u16, startup_file: String, document_root: String, open_browser: bool, manager_port: u16 }
#[derive(Clone, Deserialize)]
struct Service { name: String, enabled: bool, executable: HashMap<String, String>, arguments: Vec<String>, working_directory: String, #[serde(default)] environment: HashMap<String,String>, start_order: i32, #[serde(default)] version_command: Vec<String>, #[serde(default)] update_url: String }
#[derive(Deserialize)]
struct Settings { application: Application, services: Vec<Service> }
#[derive(Serialize)]
struct Status { name: String, enabled: bool, running: bool, error: Option<String> }
struct State { root: PathBuf, settings: Settings, children: HashMap<String,Child>, service_errors: HashMap<String,String>, update_states: HashMap<String,serde_json::Value> }
type Shared = Arc<Mutex<State>>;

#[derive(Clone)]
enum UserEvent { Minimize, Maximize, Close, Drag, OpenBrowser }

#[derive(Deserialize)]
struct InterfaceSettings { #[serde(default)] window: WindowSettings, #[serde(default)] tray: TraySettings }
#[derive(Default, Deserialize)]
struct WindowSettings { #[serde(default = "default_width")] width: f64, #[serde(default = "default_height")] height: f64 }
#[derive(Default, Deserialize)]
struct TraySettings { #[serde(default)] enabled: bool, #[serde(default)] tooltip: String, #[serde(default)] labels: HashMap<String,String> }
fn default_width()->f64 {920.0}
fn default_height()->f64 {710.0}

fn load_icon(root: &Path) -> Result<(TrayIcon, WindowIcon),String> {
    let path=root.join("assets/tray.png");
    let image=image::open(&path).map_err(|e|format!("{}: {}", path.display(), e))?.into_rgba8();
    let (w,h)=image.dimensions();
    let rgba=image.into_raw();
    let tray=TrayIcon::from_rgba(rgba.clone(),w,h).map_err(|e|e.to_string())?;
    let window=WindowIcon::from_rgba(rgba,w,h).map_err(|e|e.to_string())?;
    Ok((tray,window))
}

fn exit_services(shared:&Shared) {
    if let Ok(mut s)=shared.lock() {
        let names=s.children.keys().cloned().collect::<Vec<_>>();
        for name in names {let _=stop(&mut s,&name);}
    }
}


fn platform() -> &'static str { if cfg!(windows) { "windows" } else if cfg!(target_os="macos") { "macos" } else { "linux" } }
fn replace_vars(value: &str, root: &Path, app: &Application) -> String {
    value.replace("{app}", &root.to_string_lossy())
        .replace("{host}", &app.host).replace("{port}", &app.port.to_string())
        .replace("{document_root}", &root.join(&app.document_root).to_string_lossy())
}
fn executable_path(state: &State, svc: &Service) -> Result<PathBuf,String> {
    let raw=svc.executable.get(platform()).ok_or_else(|| format!("No executable configured for {}",platform()))?;
    let expanded=replace_vars(raw,&state.root,&state.settings.application);
    let normalized=if cfg!(windows) {expanded.replace('/', "\\")} else {expanded};
    let path=PathBuf::from(normalized);
    let path=if path.is_absolute() {path} else {state.root.join(path)};
    if !path.is_file() {return Err(format!("Executable missing: {}",path.display()));}
    Ok(path)
}
fn is_running(state: &mut State, name: &str) -> bool {
    if let Some(child)=state.children.get_mut(name) { matches!(child.try_wait(),Ok(None)) } else { false }
}
fn start(state: &mut State, name: &str) -> Result<(),String> {
    if is_running(state,name) {return Ok(());}
    state.service_errors.remove(name);
    let svc=state.settings.services.iter().find(|x|x.name==name).ok_or("Unknown service")?.clone();
    let exe=executable_path(state,&svc)?;
    fs::create_dir_all(state.root.join("logs")).map_err(|e|e.to_string())?;
    let log_path=state.root.join("logs").join(format!("{}.log", name.replace(|c:char| !c.is_ascii_alphanumeric(), "_")));
    let log=OpenOptions::new().append(true).create(true).open(&log_path).map_err(|e|e.to_string())?;
    let err=log.try_clone().map_err(|e|e.to_string())?;
    let wd=PathBuf::from(replace_vars(&svc.working_directory,&state.root,&state.settings.application));
    let wd=if wd.is_absolute(){wd}else{state.root.join(wd)};
    let mut cmd=Command::new(exe);
    cmd.current_dir(wd).stdin(Stdio::null()).stdout(Stdio::from(log)).stderr(Stdio::from(err));
    // Paths and initialization belong to the portable launcher, not to a fixed installation.
    
    let mariadb_args=if name=="MariaDB" {database::prepare(&state.root,3306)?} else {Vec::new()};
    if name=="PHP" {
        let session_dir=state.root.join("data/sessions");
        fs::create_dir_all(&session_dir).map_err(|e|e.to_string())?;
        cmd.arg("-d").arg(format!("session.save_path={}",session_dir.display()));
    }
    for arg in &svc.arguments {cmd.arg(replace_vars(arg,&state.root,&state.settings.application));}
    for arg in mariadb_args {cmd.arg(arg);}
    for (k,v) in &svc.environment {cmd.env(k,replace_vars(v,&state.root,&state.settings.application));}
    #[cfg(windows)] {
        use std::os::windows::process::CommandExt;
        cmd.creation_flags(0x08000000);
    }
    let mut child=cmd.spawn().map_err(|e|format!("Could not start {name}: {e}"))?;
    if name=="MariaDB" {
        if let Err(e)=database::wait_ready(&mut child,3306) {
            let _=child.kill();let _=child.wait();return Err(e);
        }
        if database::bootstrap_pending(&state.root) {
            if let Err(e)=database::ensure_first_run(&state.root,3306) {
                let _=child.kill();let _=child.wait();return Err(e);
            }
        }
    } else {
        thread::sleep(Duration::from_millis(250));
        if let Ok(Some(status))=child.try_wait() {
            return Err(format!("{name} exited immediately ({status}). See {}",log_path.display()));
        }
    }
    state.children.insert(name.to_string(),child);
    state.service_errors.remove(name);
    Ok(())
}
fn stop(state: &mut State, name: &str) -> Result<(),String> {
    if let Some(mut child)=state.children.remove(name) {
        if matches!(child.try_wait(),Ok(None)) { child.kill().map_err(|e|e.to_string())?; child.wait().map_err(|e|e.to_string())?; }
    }
    Ok(())
}
fn restart(state: &mut State,name:&str)->Result<(),String>{stop(state,name)?;start(state,name)}
fn version(state:&State,name:&str)->Result<String,String>{
    let svc=state.settings.services.iter().find(|s|s.name==name).ok_or("Unknown service")?;
    let exe=executable_path(state,svc)?;
    if svc.version_command.is_empty() {return Err("No version command configured".into());}
    let result=Command::new(exe).args(&svc.version_command).output().map_err(|e|e.to_string())?;
    let out=format!("{}{}",String::from_utf8_lossy(&result.stdout),String::from_utf8_lossy(&result.stderr));
    Ok(out.chars().take(2000).collect())
}
fn open_service_config(state:&State, name:&str) -> Result<(),String> {
    let path=match name {
        "PHP"=>state.root.join("config/php.ini"),
        "MariaDB"=>state.root.join("config/mariadb.ini"),
        "phpMyAdmin"=>state.root.join("modules/phpmyadmin/config.inc.php"),
        _=>return Err("Unknown module".into())
    };
    if !path.is_file() {return Err(format!("Configuration file missing: {}",path.display()));}
    open::that(&path).map_err(|e|format!("Cannot open configuration in the default editor: {e}"))
}
fn url(app:&Application)->String {
    format!("http://{}:{}/{}",app.host,app.port,app.startup_file.trim_start_matches('/'))
}
fn json_response(value:serde_json::Value,code:u16)->Response<std::io::Cursor<Vec<u8>>>{
    let mut r=Response::from_string(value.to_string()).with_status_code(StatusCode(code));
    r.add_header(Header::from_bytes("Content-Type","application/json; charset=utf-8").unwrap());
    r.add_header(Header::from_bytes("Cache-Control","no-store").unwrap());
    r
}
fn file_response(path:&Path, mime:&str)->Response<std::io::Cursor<Vec<u8>>>{
    match fs::read(path){Ok(content)=>{
        let mut r=Response::from_data(content);
        r.add_header(Header::from_bytes("Content-Type",mime).unwrap());
        r.add_header(Header::from_bytes("X-Content-Type-Options","nosniff").unwrap());
        r
    },Err(_)=>Response::from_string("File missing").with_status_code(StatusCode(404))}
}
fn handle_request(mut req: tiny_http::Request, shared:&Shared, manager_port:u16, proxy:&EventLoopProxy<UserEvent>){
    let raw=req.url().split('?').next().unwrap_or("/").to_owned();
    let method=req.method().clone();
    let origin=req.headers().iter().find(|h|h.field.equiv("Origin")).map(|h|h.value.as_str().to_string());
    if let Some(origin)=origin {
        if origin!=format!("http://127.0.0.1:{}",manager_port) {
            let _=req.respond(json_response(json!({"error":"Origin not allowed"}),403));return;
        }
    }
    let response=if method==Method::Get && raw=="/api/status" {
        let mut s=shared.lock().unwrap();
        let names=s.settings.services.iter().map(|x|(x.name.clone(),x.enabled)).collect::<Vec<_>>();
        let services=names.iter().map(|(name,enabled)|{
            let running=is_running(&mut s,name);
            let error=if running {None}else{s.service_errors.get(name).cloned()};
            Status{name:name.clone(),enabled:*enabled,running,error}
        }).collect::<Vec<_>>();
        let updates=["MariaDB","PHP","phpMyAdmin"].iter().filter_map(|name| {
            s.update_states.get(&format!("available:{name}")).map(|data| (name.to_string(),data.clone()))
        }).collect::<HashMap<_,_>>();
        json_response(json!({"startup_url":url(&s.settings.application),"services":services,"updates":updates}),200)
    } else if raw.starts_with("/api/update/") && (method==Method::Post || method==Method::Get) {
        let route=raw.trim_start_matches("/api/update/");
        let (name,action)=route.split_once('/').unwrap_or(("",""));
        if !["PHP","MariaDB","phpMyAdmin"].contains(&name) {
            json_response(json!({"error":"Unknown update module"}),404)
        } else if method==Method::Get && action=="status" {
            let s=shared.lock().unwrap();
            json_response(s.update_states.get(name).cloned().unwrap_or(json!({"state":"idle"})),200)
        } else if method==Method::Post && ["check","install"].contains(&action) {
            let mut s=shared.lock().unwrap();
            let busy=s.update_states.get(name).and_then(|v|v["state"].as_str()).map(|v|v=="checking"||v=="installing").unwrap_or(false);
            if busy {
                json_response(json!({"error":"Operation already in progress"}),409)
            } else {
                {
                    s.update_states.insert(name.to_string(),json!({"state":if action=="check" {"checking"} else {"installing"}}));
                    let shared_job=Arc::clone(shared);
                    let job_name=name.to_string();
                    let job_action=action.to_string();
                    thread::spawn(move||{
                        let root={shared_job.lock().unwrap().root.clone()};
                        // Compare versions before stopping a running service.
                        let current_check=if job_action=="install" {Some(updater::check(&root,&job_name))} else {None};
                        let mut result=match current_check {
                            Some(Ok(ref info)) if info["update_available"].as_bool()==Some(false) => {
                                let version=info["installed"].as_str().unwrap_or("unknown");
                                Ok(json!({"message":format!("{} is already up to date ({})",job_name,version)}))
                            },
                            Some(Err(error)) => Err(error),
                            _ => {
                                let mut was_running=false;
                                let mut stop_error=None;
                                if job_action=="install" && job_name!="phpMyAdmin" {
                                    if let Ok(mut state)=shared_job.lock() {
                                        was_running=is_running(&mut state,&job_name);
                                        if was_running {
                                            if let Err(error)=stop(&mut state,&job_name) {
                                                stop_error=Some(error);
                                            }
                                        }
                                    }
                                }
                                if let Some(error)=stop_error {
                                    Err(error)
                                } else {
                                    let mut outcome=if job_action=="check" {updater::check(&root,&job_name)} else {updater::install(&root,&job_name)};
                                    if job_action=="install" && job_name!="phpMyAdmin" {
                                        if let Ok(mut state)=shared_job.lock() {
                                            if outcome.is_ok() || was_running {
                                                match start(&mut state,&job_name) {
                                                    Ok(()) => if let Ok(ref mut info)=outcome {
                                                        if !info["message"].as_str().unwrap_or("").contains("already up to date") {
                                                            info["message"]=json!(format!("{} Installed/updated and started successfully.",job_name));
                                                        }
                                                    },
                                                    Err(e) => {
                                                        state.service_errors.insert(job_name.clone(),e.clone());
                                                        outcome=Err(format!("Installation completed but {} could not start: {}",job_name,e));
                                                    }
                                                }
                                            }
                                        }
                                    }
                                    outcome
                                }
                            }
                        };
                        // Refresh the cached release information after a successful installation.
                        // Otherwise the startup notice can keep saying "Not installed".
                        let refreshed=if job_action=="install" && result.is_ok() {
                            Some(updater::check(&root,&job_name))
                        } else {None};
                        let data=match result {
                            Ok(data)=>json!({"state":"done","result":data}),
                            Err(e)=>json!({"state":"error","error":e})
                        };
                        if let Ok(mut s)=shared_job.lock(){
                            if let Some(Ok(info))=refreshed {
                                s.update_states.insert(format!("available:{}",job_name),info);
                            }
                            s.update_states.insert(job_name,data);
                        }
                    });
                    json_response(json!({"state":"started"}),202)
                }
            }
        } else {json_response(json!({"error":"Unsupported update action"}),404)}
    } else if method==Method::Post && raw.starts_with("/api/config/") {
        let name=raw.trim_start_matches("/api/config/");
        let s=shared.lock().unwrap();
        match open_service_config(&s,name) {
            Ok(())=>json_response(json!({"ok":true}),200),
            Err(e)=>json_response(json!({"error":e}),400)
        }
    } else if method==Method::Post && raw.starts_with("/api/window/") {
        let command=match raw.trim_start_matches("/api/window/") {
            "minimize"=>Some(UserEvent::Minimize),
            "maximize"=>Some(UserEvent::Maximize),
            "close"=>Some(UserEvent::Close),
            "drag"=>Some(UserEvent::Drag),
            "open-browser"=>Some(UserEvent::OpenBrowser),
            _=>None,
        };
        match command {
            Some(event)=> match proxy.send_event(event) {
                Ok(())=>json_response(json!({"ok":true}),200),
                Err(_)=>json_response(json!({"error":"Window unavailable"}),503)
            },
            None=>json_response(json!({"error":"Unknown window action"}),404)
        }
    } else if method==Method::Post && raw=="/api/restart-all" {
        let mut s=shared.lock().unwrap();
        let mut names=s.settings.services.iter().filter(|x|x.enabled).map(|x|(x.start_order,x.name.clone())).collect::<Vec<_>>();
        names.sort();
        for (_,name) in names.iter().rev(){let _=stop(&mut s,name);}
        let mut errs=Vec::new();
        for (_,name) in &names {if let Err(e)=start(&mut s,name){errs.push(format!("{}: {}",name,e));}}
        if errs.is_empty(){json_response(json!({"ok":true}),200)}else{json_response(json!({"error":errs.join("; ")}),500)}
    } else if method==Method::Post && raw.starts_with("/api/service/") {
        let path=raw.trim_start_matches("/api/service/");
        let (encoded,action)=path.rsplit_once('/').unwrap_or(("",""));
        // Names are plain ASCII identifiers to avoid ambiguity in URL parsing.
        if !encoded.chars().all(|c|c.is_ascii_alphanumeric()||c=='_'||c=='-') {
            json_response(json!({"error":"Invalid service identifier"}),400)
        } else {
            let mut s=shared.lock().unwrap();
            let result=match action {"start"=>start(&mut s,encoded).map(|_|json!({"ok":true})),"stop"=>stop(&mut s,encoded).map(|_|json!({"ok":true})),"restart"=>restart(&mut s,encoded).map(|_|json!({"ok":true})),"version"=>version(&s,encoded).map(|v|json!({"version":v})),_=>Err("Unsupported action".into())};
            if let Err(ref error)=result {if action=="start"||action=="restart" {s.service_errors.insert(encoded.to_owned(),error.clone());}}
            match result {Ok(v)=>json_response(v,200),Err(e)=>json_response(json!({"error":e}),400)}
        }
    } else if method==Method::Get {
        let root=shared.lock().unwrap().root.join("manager");
        match raw.as_str(){"/"|"/index.html"=>file_response(&root.join("index.html"),"text/html; charset=utf-8"),"/main.css"=>file_response(&root.join("main.css"),"text/css; charset=utf-8"),"/main.js"=>file_response(&root.join("main.js"),"text/javascript; charset=utf-8"),"/tray.png"=>file_response(&shared.lock().unwrap().root.join("assets/tray.png"),"image/png"),"/icon.png"=>file_response(&shared.lock().unwrap().root.join("assets/icon.png"),"image/png"),_=>json_response(json!({"error":"Not found"}),404)}
    }else{json_response(json!({"error":"Not found"}),404)};
    let mut discard=[0u8;1024]; let _=req.as_reader().read(&mut discard);
    let _=req.respond(response);
}
fn main()->Result<(), Box<dyn std::error::Error>>{
    let exe=std::env::current_exe()?;
    let root=exe.parent().ok_or("No application directory")?.to_path_buf();
    let settings:Settings=serde_json::from_slice(&fs::read(root.join("config/services.json"))?)?;
    if settings.application.host!="127.0.0.1" {return Err("Only 127.0.0.1 is supported in this build".into());}
    if settings.application.manager_port==settings.application.port {return Err("Manager and application ports must differ".into());}
    let manager_port=settings.application.manager_port;
    updater::configure_phpmyadmin(&root)?;
    let mut state=State{root,settings,children:HashMap::new(),service_errors:HashMap::new(),update_states:HashMap::new()};
    let mut ordered=state.settings.services.iter().filter(|s|s.enabled).map(|s|(s.start_order,s.name.clone())).collect::<Vec<_>>();
    ordered.sort();
    for (_,name) in &ordered {if let Err(e)=start(&mut state,name){state.service_errors.insert(name.clone(),e.clone());eprintln!("Could not start {}: {}",name,e);}}
    let app=state.settings.application.clone();
    let app_name=app.name.clone();
    let shared=Arc::new(Mutex::new(state));
    let update_watch=Arc::clone(&shared);
    thread::spawn(move || {
        loop {
            for name in ["MariaDB","PHP","phpMyAdmin"] {
                let root={match update_watch.lock(){Ok(s)=>s.root.clone(),Err(_)=>return}};
                let result=updater::check(&root,name);
                if let Ok(mut s)=update_watch.lock() {
                    let info=match result {
                        Ok(info)=>info,
                        Err(error)=>json!({"error":error})
                    };
                    s.update_states.insert(format!("available:{name}"),info);
                }
            }
            thread::sleep(Duration::from_secs(6*60*60));
        }
    });
    let cleanup_for_exit=Arc::clone(&shared);
    let interface:InterfaceSettings=serde_json::from_slice(&fs::read(cleanup_for_exit.lock().unwrap().root.join("config/interface.json"))?)?;
    let root_for_icon=cleanup_for_exit.lock().unwrap().root.clone();
    let event_loop = EventLoopBuilder::<UserEvent>::with_user_event().build();
    let proxy=event_loop.create_proxy();
    let exit_proxy=proxy.clone();
    ctrlc::set_handler(move||{let _=exit_proxy.send_event(UserEvent::Close);})?;
    let server=Server::http(format!("127.0.0.1:{}",manager_port)).map_err(|e|format!("Manager server failed: {e}"))?;
    let manager_url=format!("http://127.0.0.1:{}/",manager_port);
    thread::spawn(move || {
        for req in server.incoming_requests() { handle_request(req, &shared, manager_port, &proxy); }
    });
    if app.open_browser {
        let target=url(&app);
        let app_host=app.host.clone();
        let app_port=app.port;
        // Wait for the configured PHP server to become available before opening it.
        thread::spawn(move||{
            for _ in 0..40 {if std::net::TcpStream::connect((app_host.as_str(),app_port)).is_ok(){let _=open::that(&target);return;}thread::sleep(Duration::from_millis(250));}
            eprintln!("Application web server not ready; use manager to diagnose.");
        });
    }
    let (tray_image,window_image)=load_icon(&root_for_icon)?;
    let window = WindowBuilder::new()
        .with_title(format!("{} Manager", app_name))
        .with_decorations(false)
        .with_window_icon(Some(window_image))
        .with_inner_size(tao::dpi::LogicalSize::new(
            if interface.window.width > 400.0 {interface.window.width}else{920.0},
            if interface.window.height > 300.0 {interface.window.height}else{710.0}
        ))
        .build(&event_loop)?;
    let _webview = WebViewBuilder::new()
        .with_url(&manager_url)
        .build(&window)?;

    let mut menu_items:HashMap<String,MenuItem>=HashMap::new();
    let tray_menu=Menu::new();
    for (key,default) in [
        ("open_manager","Open Manager"),
        ("open_browser","Open Main Page"),
        ("restart_services","Restart Services"),
        ("exit","Exit SQL PORT")
    ] {
        let label=interface.tray.labels.get(key).map(String::as_str).unwrap_or(default);
        let item=MenuItem::new(label,true,None);
        tray_menu.append(&item)?;
        menu_items.insert(key.to_owned(),item);
    }
    let mut tray=if interface.tray.enabled {
        Some(TrayIconBuilder::new().with_icon(tray_image)
            .with_tooltip(if interface.tray.tooltip.is_empty(){app_name.clone()}else{interface.tray.tooltip})
            .with_menu(Box::new(tray_menu)).build()?)
    } else {None};

    let exit_state=Arc::clone(&cleanup_for_exit);
    let menu_state=Arc::clone(&cleanup_for_exit);
    let open_url=url(&app);
    event_loop.run(move |event, _, control_flow| {
        *control_flow = ControlFlow::WaitUntil(Instant::now()+Duration::from_millis(100));
        match event {
            Event::UserEvent(UserEvent::Minimize) => {window.set_visible(false);}
            Event::UserEvent(UserEvent::Maximize) => {window.set_maximized(!window.is_maximized());}
            Event::UserEvent(UserEvent::Drag) => {let _=window.drag_window();}
            Event::UserEvent(UserEvent::OpenBrowser) => {let _=open::that(&open_url);}
            Event::UserEvent(UserEvent::Close) |
            Event::WindowEvent {event:WindowEvent::CloseRequested,..} => {
                exit_services(&exit_state);
                tray.take();
                *control_flow=ControlFlow::Exit;
            }
            Event::MainEventsCleared => {
                while let Ok(event)=TrayIconEvent::receiver().try_recv() {
                    if matches!(event,TrayIconEvent::Click {..}) {
                        window.set_visible(true);
                        window.set_minimized(false);
                        window.set_focus();
                    }
                }
                while let Ok(event)=MenuEvent::receiver().try_recv() {
                    let selected=menu_items.iter().find(|(_,item)|item.id()==&event.id).map(|(k,_)|k.as_str());
                    match selected {
                        Some("open_manager")=>{window.set_visible(true);window.set_minimized(false);window.set_focus();}
                        Some("open_browser")=>{let _=open::that(&open_url);}
                        Some("restart_services")=>{
                            if let Ok(mut s)=menu_state.lock(){
                                let mut names=s.settings.services.iter().filter(|v|v.enabled).map(|v|(v.start_order,v.name.clone())).collect::<Vec<_>>();
                                names.sort();
                                for (_,name) in names.iter().rev(){let _=stop(&mut s,name);}
                                for (_,name) in &names {let _=start(&mut s,name);}
                            }
                        }
                        Some("exit")=>{exit_services(&exit_state);tray.take();*control_flow=ControlFlow::Exit;}
                        _=>{}
                    }
                }
            }
            _=>{}
        }
    });
    Ok(())
}
