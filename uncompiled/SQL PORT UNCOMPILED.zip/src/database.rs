use std::{fs, net::{TcpListener,TcpStream}, path::{Path,PathBuf}, process::{Child,Command,Stdio}, thread, time::{Duration,Instant}};

fn mariadb_root(root:&Path)->PathBuf { root.join("modules").join("mariadb") }
fn data_path(root:&Path)->PathBuf { root.join("data").join("mariadb") }
fn binary(base:&Path,name:&str)->PathBuf {
    base.join("bin").join(format!("{}{}",name,if cfg!(windows){".exe"}else{""}))
}
fn data_initialized(dir:&Path)->bool { dir.join("mysql").is_dir() }
fn bootstrap_marker(root:&Path)->PathBuf { data_path(root).join(".myapp-bootstrap-pending") }

pub fn bootstrap_pending(root:&Path)->bool { bootstrap_marker(root).is_file() }

pub fn prepare(root:&Path,port:u16)->Result<Vec<String>,String> {
    let base=mariadb_root(root);
    let dir=data_path(root);
    fs::create_dir_all(&dir).map_err(|e|format!("Cannot create {}: {e}",dir.display()))?;
    if !data_initialized(&dir) {
        // An empty placeholder file ships in the portable ZIP; it is not database data.
        let placeholder=dir.join(".gitkeep");
        if placeholder.is_file(){fs::remove_file(&placeholder).map_err(|e|e.to_string())?;}
        let has_files=fs::read_dir(&dir).map_err(|e|e.to_string())?.next().is_some();
        if has_files { return Err(format!("MariaDB data directory {} contains files but no mysql system tables. Refusing to overwrite it; restore or inspect it manually.",dir.display())); }
        let windows_installer=binary(&base,"mariadb-install-db");
        let unix_installer=base.join("scripts").join("mariadb-install-db");
        let bin_installer=binary(&base,"mariadb-install-db");
        let installer=if windows_installer.is_file(){windows_installer}
            else if bin_installer.is_file(){bin_installer}
            else if unix_installer.is_file(){unix_installer}
            else {return Err(format!("First-run MariaDB setup requires mariadb-install-db in {}. The downloaded package does not contain a usable initializer.",base.display()));};
        let mut command=Command::new(&installer);
        command.arg(format!("--datadir={}",dir.display()));
        if !cfg!(windows) {
            command.arg(format!("--basedir={}",base.display()));
            command.arg("--auth-root-authentication-method=normal");
        }
        command.current_dir(&base);
        #[cfg(windows)] {
            use std::os::windows::process::CommandExt;
            command.creation_flags(0x08000000);
        }
        let output=command.output().map_err(|e|format!("Cannot run {}: {e}",installer.display()))?;
        if !output.status.success() || !data_initialized(&dir) {
            return Err(format!("MariaDB first-run initialization failed (exit {}). {} {}",output.status,
                String::from_utf8_lossy(&output.stdout).trim(),String::from_utf8_lossy(&output.stderr).trim()));
        }
        fs::write(bootstrap_marker(root),b"First-run credentials setup is pending.\n")
            .map_err(|e|format!("Cannot record MariaDB first-run setup: {e}"))?;
    }
    // Detect port conflicts before spawning: an unrelated database must not be mistaken for ours.
    let binding=TcpListener::bind(("127.0.0.1",port)).map_err(|e|format!("MariaDB cannot use port {port}: {e}"))?;
    drop(binding);
    Ok(vec![format!("--basedir={}",base.display()), format!("--datadir={}",dir.display()),format!("--port={port}"),"--bind-address=127.0.0.1".into()])
}

pub fn wait_ready(child:&mut Child,port:u16)->Result<(),String> {
    let start=Instant::now();
    while start.elapsed()<Duration::from_secs(15) {
        match child.try_wait(){
            Ok(Some(status))=>return Err(format!("MariaDB exited during startup ({status}). See logs/MariaDB.log")),
            Err(e)=>return Err(format!("Cannot monitor MariaDB: {e}")),
            _=>{}
        }
        if TcpStream::connect_timeout(&format!("127.0.0.1:{port}").parse().unwrap(),Duration::from_millis(300)).is_ok() {return Ok(());}
        thread::sleep(Duration::from_millis(250));
    }
    Err(format!("MariaDB did not listen on port {port} within 15 seconds. See logs/MariaDB.log"))
}

pub fn ensure_first_run(root:&Path,port:u16)->Result<(),String>{
    if !bootstrap_pending(root) {return Ok(());}
    let base=mariadb_root(root);
    let client=binary(&base,"mariadb");
    let mysql=binary(&base,"mysql");
    let client=if client.is_file(){client}else{mysql};
    if !client.is_file(){return Err(format!("MariaDB SQL client missing at {}",client.display()));}

    // Runs only after MyApp has initialized an empty data directory. Never resets a preexisting database.
    // First configure the TCP root account, then the localhost account (which may be the current login).
    let sql="CREATE DATABASE IF NOT EXISTS `main` CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;\n\
CREATE USER IF NOT EXISTS 'root'@'127.0.0.1' IDENTIFIED BY 'root';\n\
ALTER USER 'root'@'127.0.0.1' IDENTIFIED BY 'root';\n\
GRANT ALL PRIVILEGES ON *.* TO 'root'@'127.0.0.1' WITH GRANT OPTION;\n\
ALTER USER 'root'@'localhost' IDENTIFIED BY 'root';\n";
    let mut command=Command::new(&client);
    command.arg("--protocol=tcp").arg("--host=127.0.0.1").arg(format!("--port={port}"))
        .arg("--user=root").arg("--batch").arg("--skip-column-names")
        .stdin(Stdio::piped()).stdout(Stdio::piped()).stderr(Stdio::piped());
    #[cfg(windows)] {
        use std::os::windows::process::CommandExt;
        command.creation_flags(0x08000000);
    }
    let mut child=command.spawn().map_err(|e|format!("Cannot run MariaDB client: {e}"))?;
    {
        use std::io::Write;
        let mut stdin=child.stdin.take().ok_or("Cannot write initial MariaDB SQL")?;
        stdin.write_all(sql.as_bytes()).map_err(|e|format!("Cannot configure MariaDB root: {e}"))?;
    }
    let output=child.wait_with_output().map_err(|e|format!("Cannot finish MariaDB setup: {e}"))?;
    if !output.status.success(){return Err(format!("MariaDB first-run root/main setup failed: {}",String::from_utf8_lossy(&output.stderr).trim()));}
    fs::remove_file(bootstrap_marker(root)).map_err(|e|format!("Cannot mark MariaDB initialization complete: {e}"))?;
    Ok(())
}
