use serde_json::{json,Value};
use std::{fs::{self,File},io::{Read,Write},path::{Path,PathBuf},process::Command};
use sha2::{Digest,Sha256};

struct Package { version:String, url:String, sha256:Option<String>, archive:String }

fn text(url:&str)->Result<String,String>{
    ureq::get(url).timeout(std::time::Duration::from_secs(25)).call()
        .map_err(|e|format!("{}: {}",url,e))?.into_string().map_err(|e|e.to_string())
}
fn data(url:&str)->Result<Value,String>{ serde_json::from_str(&text(url)?).map_err(|e|e.to_string()) }

fn num_version(s:&str)->Vec<u32>{
    s.split(|c:char|!c.is_ascii_digit()&&c!='.').next().unwrap_or("")
        .split('.').filter_map(|p|p.parse::<u32>().ok()).collect()
}
fn greater(a:&str,b:&str)->bool{num_version(a)>num_version(b)}

fn latest(name:&str)->Result<Package,String>{
    match name {
        "phpMyAdmin"=>{
            let v=data("https://www.phpmyadmin.net/home_page/version.json")?;
            let version=v["version"].as_str().ok_or("Official phpMyAdmin version unavailable")?.to_string();
            Ok(Package{version,url:"https://www.phpmyadmin.net/downloads/phpMyAdmin-latest-all-languages.zip".into(),sha256:None,archive:"zip".into()})
        },
        "PHP"=>{
            if !cfg!(windows){return Err("PHP does not publish a compatible official portable binary archive for this platform. No installation was attempted.".into());}
            if std::env::consts::ARCH!="x86_64" {return Err("Official x64 Windows PHP package is required".into());}
            let html=text("https://windows.php.net/downloads/releases/")?;
            let re=regex::Regex::new(r#"php-(\d+\.\d+\.\d+)-nts-Win32-[^"/<> ]+-x64\.zip"#).unwrap();
            let mut names=re.captures_iter(&html).map(|m|(m[1].to_string(),m[0].to_string())).collect::<Vec<_>>();
            names.sort_by(|a,b|num_version(&a.0).cmp(&num_version(&b.0)));
            let (version,file)=names.pop().ok_or("No compatible official PHP x64 NTS ZIP was found on windows.php.net")?;
            Ok(Package{version,url:format!("https://windows.php.net/downloads/releases/{}",file),sha256:None,archive:"zip".into()})
        },
        "MariaDB"=>{
            // Stable maintained LTS branch; never silently switch an existing database to another major branch.
            let v=data("https://downloads.mariadb.org/rest-api/mariadb/11.4/latest/")?;
            let releases=v["releases"].as_object().ok_or("MariaDB release API returned no releases")?;
            let (version,release)=releases.iter().max_by(|(a,_),(b,_)|num_version(a).cmp(&num_version(b))).ok_or("No MariaDB stable release")?;
            let files=release["files"].as_array().ok_or("MariaDB release files unavailable")?;
            let preferred=files.iter().filter_map(|f|{
                let filename=f["file_name"].as_str()?;
                let compatible=if cfg!(windows){filename.ends_with("-winx64.zip")}
                    else if cfg!(target_os="linux"){filename.contains("linux")&&filename.contains("x86_64")&&filename.ends_with(".tar.gz")}
                    else {filename.contains("osx")&&filename.ends_with(".tar.gz")};
                if !compatible{return None;}
                let url=f["file_download_url"].as_str()?.to_string();
                let sha=f["checksum"]["sha256sum"].as_str().map(String::from);
                Some((filename.to_string(),url,sha))
            }).next().ok_or("MariaDB has no compatible portable package for this operating system/architecture")?;
            Ok(Package{version:version.clone(),url:preferred.1,sha256:preferred.2,archive:if preferred.0.ends_with(".zip"){"zip"}else{"tar.gz"}.into()})
        },
        _=>Err("Unknown module".into())
    }
}
fn module_path(root:&Path,name:&str)->Result<PathBuf,String>{
    if name=="phpMyAdmin" {
        return Ok(root.join("modules/phpmyadmin"));
    }
    let config=data_from_file(&root.join("config/services.json"))?;
    let services=config["services"].as_array().ok_or("Service configuration invalid")?;
    let service=services.iter().find(|s|s["name"].as_str()==Some(name)).ok_or("Unknown service")?;
    let platform=if cfg!(windows){"windows"}else if cfg!(target_os="macos"){"macos"}else{"linux"};
    let relative=service["executable"][platform].as_str().ok_or("No executable for platform")?;
    let exe=PathBuf::from(relative.replace("{app}",&root.to_string_lossy()));
    let exe=if exe.is_absolute(){exe}else{root.join(exe)};
    let bin=exe.parent().ok_or("Executable has no parent directory")?;
    if name=="MariaDB" || (!cfg!(windows)&&name=="PHP") {
        Ok(bin.parent().ok_or("Executable layout is invalid")?.to_path_buf())
    }else{Ok(bin.to_path_buf())}
}
fn data_from_file(path:&Path)->Result<Value,String>{
    let text=fs::read_to_string(path).map_err(|e|e.to_string())?;
    serde_json::from_str(&text).map_err(|e|e.to_string())
}
fn installed(root:&Path,name:&str)->Option<String>{
    let path=module_path(root,name).ok()?;
    if name=="phpMyAdmin" {
        let file=fs::read_to_string(path.join("libraries/classes/Version.php")).ok()?;
        let re=regex::Regex::new(r#"(?m)VERSION\s*=\s*['\"]([^'\"]+)"#).ok()?;
        return re.captures(&file).map(|m|m[1].to_string());
    }
    let exe=if name=="PHP" {
        path.join(if cfg!(windows){"php.exe"}else{"bin/php"})
    }else{path.join("bin").join(if cfg!(windows){"mariadbd.exe"}else{"mariadbd"})};
    if !exe.is_file(){return None;}
    let output=Command::new(exe).arg(if name=="PHP"{"-v"}else{"--version"}).output().ok()?;
    let text=String::from_utf8_lossy(&output.stdout);
    let text=format!("{}{}",text,String::from_utf8_lossy(&output.stderr));
    let re=if name=="PHP" {regex::Regex::new(r"PHP\s+(\d+\.\d+\.\d+)").ok()?}
        else{regex::Regex::new(r"(\d+\.\d+\.\d+)-MariaDB").ok()?};
    re.captures(&text).map(|m|m[1].to_string())
}
pub fn check(root:&Path,name:&str)->Result<Value,String>{
    let package=latest(name)?;
    let current=installed(root,name);
    let outdated=current.as_ref().map(|v|greater(&package.version,v)).unwrap_or(true);
    Ok(json!({"module":name,"installed":current,"available":package.version,"update_available":outdated,
        "message":format!("Installed: {}; official: {}; {}",current.as_deref().unwrap_or("missing"),package.version,
            if outdated{"Install / Update available"}else{"Up to date"})}))
}
fn extract_zip(archive:&Path,dest:&Path)->Result<(),String>{
    let mut zip=zip::ZipArchive::new(File::open(archive).map_err(|e|e.to_string())?).map_err(|e|e.to_string())?;
    for i in 0..zip.len(){
        let mut entry=zip.by_index(i).map_err(|e|e.to_string())?;
        let safe=entry.enclosed_name().ok_or("Unsafe path in archive")?;
        let path=dest.join(safe);
        if entry.is_dir(){fs::create_dir_all(path).map_err(|e|e.to_string())?;continue;}
        if let Some(parent)=path.parent(){fs::create_dir_all(parent).map_err(|e|e.to_string())?;}
        let mut out=File::create(path).map_err(|e|e.to_string())?;
        std::io::copy(&mut entry,&mut out).map_err(|e|e.to_string())?;
    }
    Ok(())
}
fn extract_tar(archive:&Path,dest:&Path)->Result<(),String>{
    let f=File::open(archive).map_err(|e|e.to_string())?;
    let mut tar=tar::Archive::new(flate2::read::GzDecoder::new(f));
    // The tar crate rejects traversal outside the destination.
    tar.unpack(dest).map_err(|e|e.to_string())
}
fn find_payload(root:&Path,name:&str)->Result<PathBuf,String>{
    let expect=if name=="PHP" {if cfg!(windows){"php.exe"}else{"php"}}
        else if name=="MariaDB" {if cfg!(windows){"mariadbd.exe"}else{"mariadbd"}}
        else {"index.php"};
    let mut stack=vec![root.to_path_buf()];
    while let Some(dir)=stack.pop(){
        for item in fs::read_dir(&dir).map_err(|e|e.to_string())? {
            let item=item.map_err(|e|e.to_string())?;
            if item.file_type().map_err(|e|e.to_string())?.is_dir(){stack.push(item.path());}
            else if item.file_name()==expect {
                let parent=item.path().parent().unwrap().to_path_buf();
                return Ok(if name=="MariaDB" {parent.parent().ok_or("Invalid MariaDB archive")?.to_path_buf()}
                    else if name=="PHP" && !cfg!(windows){parent.parent().ok_or("Invalid PHP archive")?.to_path_buf()}
                    else {parent});
            }
        }
    }
    Err(format!("Downloaded archive does not contain required {} file",expect))
}
pub fn install(root:&Path,name:&str)->Result<Value,String>{
    let pkg=latest(name)?;
    if let Some(current)=installed(root,name) {
        if !greater(&pkg.version,&current) {
            return Ok(json!({"message":format!("{} is already up to date ({})",name,current)}));
        }
    }
    let destination=module_path(root,name)?;
    let staging=root.join("data").join(format!(".myapp-update-{}",name));
    if staging.exists(){fs::remove_dir_all(&staging).map_err(|e|e.to_string())?;}
    fs::create_dir_all(&staging).map_err(|e|e.to_string())?;
    let result=(||->Result<Value,String>{
        let archive=staging.join(if pkg.archive=="zip"{"package.zip"}else{"package.tar.gz"});
        let response=ureq::get(&pkg.url).timeout(std::time::Duration::from_secs(300)).call().map_err(|e|e.to_string())?;
        let mut reader=response.into_reader();
        let mut out=File::create(&archive).map_err(|e|e.to_string())?;
        let mut hasher=Sha256::new();
        let mut buf=[0u8;64*1024];
        let mut total=0u64;
        loop{
            let read=reader.read(&mut buf).map_err(|e|e.to_string())?;
            if read==0{break;}
            total+=read as u64;
            if total>500_000_000{return Err("Package exceeds safe download size".into());}
            out.write_all(&buf[..read]).map_err(|e|e.to_string())?;
            hasher.update(&buf[..read]);
        }
        drop(out);
        if let Some(expected)=&pkg.sha256 {
            let actual=format!("{:x}",hasher.finalize());
            if !actual.eq_ignore_ascii_case(expected){return Err("Official package SHA256 verification failed".into());}
        }
        let extracted=staging.join("extracted");
        fs::create_dir_all(&extracted).map_err(|e|e.to_string())?;
        if pkg.archive=="zip" {extract_zip(&archive,&extracted)?}else{extract_tar(&archive,&extracted)?}
        let payload=find_payload(&extracted,name)?;
        let backup=staging.join("previous");
        if destination.exists(){fs::rename(&destination,&backup).map_err(|e|format!("Cannot back up previous module: {}",e))?;}
        if let Err(error)=fs::rename(&payload,&destination){
            if backup.exists(){let _=fs::rename(&backup,&destination);}
            return Err(format!("Failed to install module: {}",error));
        }
        // Preserve existing phpMyAdmin configuration. Backup remains outside the temporary folder.
        if name=="phpMyAdmin" && backup.join("config.inc.php").is_file() {
            fs::copy(backup.join("config.inc.php"),destination.join("config.inc.php")).map_err(|e|e.to_string())?;
        }
        if name=="phpMyAdmin" { configure_phpmyadmin(root)?; }
        if backup.exists() {
            let backups=root.join("data/module-backups");
            fs::create_dir_all(&backups).map_err(|e|e.to_string())?;
            let backup_path=backups.join(format!("{}-{}",name, std::time::SystemTime::now().duration_since(std::time::UNIX_EPOCH).map_err(|e|e.to_string())?.as_secs()));
            fs::rename(&backup,&backup_path).map_err(|e|format!("Previous module is installed but its backup could not be preserved: {}",e))?;
        }
        Ok(json!({"message":format!("{} {} installed.",name,pkg.version),"version":pkg.version}))
    })();
    let _=fs::remove_dir_all(&staging);
    result
}

// Create phpMyAdmin configuration on first install; keep user settings on updates.
pub fn configure_phpmyadmin(root: &Path) -> Result<(),String> {
    let folder=root.join("modules/phpmyadmin");
    if !folder.join("index.php").is_file() {return Ok(());}
    let config=folder.join("config.inc.php");
    if config.exists() {return Ok(());}
    let settings=data_from_file(&root.join("config/services.json"))?;
    let app=&settings["application"];
    let host=app["host"].as_str().ok_or("Missing application host")?;
    let port=app["port"].as_u64().ok_or("Missing application port")?;
    if host!="127.0.0.1" {return Err("phpMyAdmin requires loopback application host".into());}
    let mut random=[0u8;32];
    getrandom::getrandom(&mut random).map_err(|e|format!("Cannot generate phpMyAdmin secret: {e}"))?;
    let secret=random.iter().map(|b|format!("{b:02x}")).collect::<String>();
    let contents=format!("<?php\n\n    // Created by SQL PORT on first installation. Edit as needed.\n\n    $cfg['blowfish_secret'] = '{secret}';\n\n    $cfg['PmaAbsoluteUri'] = 'http://{host}:{port}/phpmyadmin/';\n\n    $i = 0;\n    $i++;\n    $cfg['Servers'][$i]['auth_type'] = 'cookie';\n    $cfg['Servers'][$i]['host'] = '127.0.0.1';\n    $cfg['Servers'][$i]['port'] = '3306';\n    $cfg['Servers'][$i]['connect_type'] = 'tcp';\n    $cfg['Servers'][$i]['AllowNoPassword'] = false;\n");
    // create_new prevents replacing existing credentials or user configuration.
    let mut file=fs::OpenOptions::new().write(true).create_new(true).open(&config).map_err(|e|e.to_string())?;
    file.write_all(contents.as_bytes()).map_err(|e|e.to_string())
}
