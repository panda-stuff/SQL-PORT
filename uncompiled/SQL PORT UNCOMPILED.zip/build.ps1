$ErrorActionPreference = 'Stop'

Set-Location $PSScriptRoot

function Check-Exit($step)
{
    if ($LASTEXITCODE -ne 0)
    {
        throw "$step failed (exit code $LASTEXITCODE)."
    }
}

try
{
    if (-not (Get-Command gh -ErrorAction SilentlyContinue))
    {
        throw 'GitHub CLI is missing. Install it with: winget install --id GitHub.cli -e'
    }

    gh auth status *> $null
    Check-Exit 'GitHub authentication (run gh auth login first)'

    # Keep downloaded binaries out of future commits without changing the repository's .gitignore.
    $exclude = Join-Path $PSScriptRoot '.git\info\exclude'
    if (-not (Select-String -Path $exclude -Pattern '^/builds/$' -Quiet))
    {
        Add-Content -Path $exclude -Value '/builds/'
    }

    git add -A
    Check-Exit 'Staging changes'

    git diff --cached --quiet
    if ($LASTEXITCODE -eq 0)
    {
        Write-Host 'No changes to commit. Nothing was built.'
        exit 0
    }
    if ($LASTEXITCODE -ne 1) { throw 'Could not check staged changes.' }

    git commit -m 'Update MyApp'
    Check-Exit 'Commit'

    git push origin main
    Check-Exit 'Push'

    $sha = (git rev-parse HEAD).Trim()
    Check-Exit 'Reading commit'
    Write-Host "Waiting for GitHub Actions build for commit $sha ..."

    $runId = $null
    for ($i = 0; $i -lt 60; $i++)
    {
        $runsJson = gh run list --workflow build.yml --event push --commit $sha --limit 20 --json databaseId,headSha
        Check-Exit 'Finding workflow run'
        $runs = @($runsJson | ConvertFrom-Json)
        $matched = @($runs | Where-Object { $_.headSha -eq $sha })
        if ($matched.Count -gt 0)
        {
            $runId = $matched[0].databaseId
            break
        }
        Start-Sleep -Seconds 5
    }
    if (-not $runId) { throw 'No build was found for this commit after 5 minutes.' }

    Write-Host "Watching GitHub Actions run $runId ..."
    gh run watch $runId --exit-status
    Check-Exit 'GitHub Actions build'

    $destination = Join-Path $PSScriptRoot "builds\$sha"
    New-Item -ItemType Directory -Force -Path $destination | Out-Null
    gh run download $runId --dir $destination
    Check-Exit 'Downloading build artifacts'

    Write-Host "`nBuild succeeded. Downloaded artifacts: $destination" -ForegroundColor Green
}
catch
{
    Write-Host "`nERROR: $_" -ForegroundColor Red
    exit 1
}